# LXC VPS Discord Bot V2

This release fixes the failure shown in the screenshot: `lxcbr0` did not exist and `lxc-net.service` failed. The installer now creates `lxcbr0` directly and does not depend on `lxc-net.service`. LXC requires the bridge named by `lxc.net.0.link` to exist before a veth can attach to it.

It also removes host-CPU pinning and uses cgroup2 CPU quota. Disk can use LXC loop-backed storage with a real filesystem size; `lxc-create` supports `-B loop` with `--fssize`.

## IMPORTANT
If the host is a sandbox/container that does not grant `CAP_NET_ADMIN` or nested namespaces, a real LXC VPS cannot be hosted there. `install.sh` checks this and stops instead of creating broken VPSes.

## Install
```bash
chmod +x install.sh
sudo ./install.sh
```
The installer runs 14 stages one-by-one: base packages, Python, LXC, LXCFS, checks, bridge, DHCP/DNS, NAT, LXCFS startup, Python environment, dependencies, and bot validation.

## Start
```bash
sudo .venv/bin/python bot.py
```

## Commands
User: `Smyvps`, `Sping`, `Snew ssh <id>`, `Snew sshx <id>`, `Smanage <id>`, `SPanel`, `Shelp`

Admin: `Screatevps <name> <ram> <disk> <cpu> <os> <@user>`, `Sdeletevps <id>`, `Smanagevps [id]`, `Saddpanel <name> <url>`, `Saddadmin <@user>`, `Screate embed <title> | <description>`, `Senable antinuke`, `Sdisable antinuke`, `Sban`, `Skick`, `Sreset` / `Sreset CONFIRM`.

OS keys: `ubuntu20.04`, `ubuntu22.04`, `ubuntu24.04`, `ubuntu26.04`.

SSH/tmate and SSHX remain separate. Neither is generated during VPS creation. They are generated only when requested.

LXCFS is primarily a host-side filesystem that makes proc/sys information container-aware; installing the package inside the guest alone does not provide that virtualization.
