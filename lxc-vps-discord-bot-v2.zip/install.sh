#!/usr/bin/env bash
set -Eeuo pipefail

log(){ echo; echo "[STEP] $*"; }
ok(){ echo "[ OK ] $*"; }
warn(){ echo "[WARN] $*"; }
die(){ echo "[ERROR] $*" >&2; exit 1; }
trap 'die "Installation failed on line $LINENO. Read the message immediately above."' ERR

[[ $EUID -eq 0 ]] || die "Run this script as root."
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"
export DEBIAN_FRONTEND=noninteractive

log "1/14 Updating package index"
apt-get update

log "2/14 Installing base utilities"
apt-get install -y ca-certificates curl wget gnupg2 lsb-release iproute2 iptables dnsmasq-base bridge-utils

log "3/14 Installing Python"
apt-get install -y python3 python3-venv python3-pip python3-dev gcc build-essential

log "4/14 Installing LXC"
apt-get install -y lxc lxc-utils lxc-templates uidmap

log "5/14 Installing LXCFS"
apt-get install -y lxcfs fuse3

log "6/14 Checking LXC commands"
for x in lxc-create lxc-start lxc-stop lxc-destroy lxc-info lxc-checkconfig ip; do command -v "$x" >/dev/null || die "$x is missing"; done

log "7/14 Checking cgroups and namespace support"
[[ -d /sys/fs/cgroup ]] || die "/sys/fs/cgroup is unavailable. This host cannot run proper cgroup-controlled LXC."
[[ -e /proc/self/ns/net ]] || die "Network namespaces are unavailable."

log "8/14 Checking CAP_NET_ADMIN"
TEST="lxc-vps-cap-test-$$"
if ! ip link add "$TEST" type dummy 2>/dev/null; then
  die "CAP_NET_ADMIN is unavailable. This is common in hosted coding sandboxes. Real LXC VPS networking cannot work here. Use a real VPS/bare-metal host with nested LXC privileges."
fi
ip link delete "$TEST" type dummy 2>/dev/null || true

log "9/14 Configuring LXC default networking"
mkdir -p /etc/lxc /etc/lxc/dnsmasq.d /var/lib/lxc /var/cache/lxc
cp -a /etc/lxc/default.conf "/etc/lxc/default.conf.backup.$(date +%s)" 2>/dev/null || true
cat >/etc/lxc/default.conf <<'EOF'
lxc.net.0.type = veth
lxc.net.0.link = lxcbr0
lxc.net.0.flags = up
lxc.net.0.name = eth0
EOF

log "10/14 Creating lxcbr0 without depending on lxc-net.service"
if ! ip link show lxcbr0 >/dev/null 2>&1; then ip link add lxcbr0 type bridge; fi
ip addr replace 10.0.3.1/24 dev lxcbr0
ip link set lxcbr0 up

cat >/etc/lxc/dnsmasq.d/vpsbot.conf <<'EOF'
interface=lxcbr0
bind-interfaces
dhcp-range=10.0.3.2,10.0.3.254,255.255.255.0,12h
dhcp-option=3,10.0.3.1
dhcp-option=6,8.8.8.8,1.1.1.1
server=8.8.8.8
server=1.1.1.1
EOF
if ! pgrep -af 'dnsmasq.*lxcbr0' >/dev/null 2>&1; then
  dnsmasq --conf-file=/etc/lxc/dnsmasq.d/vpsbot.conf --pid-file=/run/lxc-vpsbot-dnsmasq.pid
fi

log "11/14 Enabling IPv4 forwarding and NAT"
OUT_IF="$(ip route show default | awk 'NR==1{print $5}')"
[[ -n "$OUT_IF" ]] || die "No default outbound interface found."
sysctl -w net.ipv4.ip_forward=1 >/dev/null
printf 'net.ipv4.ip_forward=1\n' >/etc/sysctl.d/99-lxc-vps-bot.conf
iptables -C FORWARD -i lxcbr0 -o "$OUT_IF" -j ACCEPT 2>/dev/null || iptables -A FORWARD -i lxcbr0 -o "$OUT_IF" -j ACCEPT
iptables -C FORWARD -i "$OUT_IF" -o lxcbr0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || iptables -A FORWARD -i "$OUT_IF" -o lxcbr0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
iptables -t nat -C POSTROUTING -s 10.0.3.0/24 -o "$OUT_IF" -j MASQUERADE 2>/dev/null || iptables -t nat -A POSTROUTING -s 10.0.3.0/24 -o "$OUT_IF" -j MASQUERADE

log "12/14 Starting LXCFS"
if pgrep -x lxcfs >/dev/null 2>&1; then ok "LXCFS already running"; else nohup lxcfs -f >/var/log/lxcfs-vpsbot.log 2>&1 & sleep 2; fi
pgrep -x lxcfs >/dev/null 2>&1 || warn "LXCFS did not start; LXC can still enforce cgroup limits, but container-aware proc reporting may be unavailable."

log "13/14 Creating Python virtual environment and installing dependencies"
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip wheel
.venv/bin/python -m pip install -r requirements.txt

log "14/14 Validating bot"
.venv/bin/python -m py_compile bot.py
.venv/bin/python - <<'PY'
import bot
bot.init_db()
print("Bot import + SQLite check: OK")
PY
