import asyncio
import json
import os
import re
import shlex
import sqlite3
import subprocess
import sys
import time
from collections import defaultdict, deque
from pathlib import Path
from typing import Optional

import aiohttp
import discord
from discord.ext import commands

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.js"


def load_config(path: Path):
    text = path.read_text(encoding="utf-8")
    # config.js is deliberately kept as a simple CommonJS object. We convert
    # primitive values into JSON so Python can consume it without Node.js.
    body = text[text.find("{"):text.rfind("}") + 1]
    body = re.sub(r"//.*", "", body)
    body = re.sub(r",(\s*[}])", r"\1", body)
    body = re.sub(r"\bmodule\.exports\s*=\s*", "", body)
    # Quote unquoted JS keys.
    body = re.sub(r"([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)\s*:", r'\1"\2":', body)
    body = body.replace("true", "true").replace("false", "false")
    try:
        return json.loads(body)
    except Exception as exc:
        raise RuntimeError(f"Could not parse config.js: {exc}") from exc


CFG = load_config(CONFIG_PATH)
TOKEN = CFG["DISCORD_TOKEN"]
PREFIX = CFG.get("PREFIX", "S")
DB_PATH = BASE_DIR / CFG.get("DATABASE", "vpsbot.db")
LXC_STORAGE = Path(CFG.get("LXC_STORAGE", "/var/lib/lxc"))
LXC_BRIDGE = CFG.get("LXC_BRIDGE", "lxcbr0")
COMMAND_TIMEOUT = int(CFG.get("COMMAND_TIMEOUT", 300))

OS_IMAGES = {
    "ubuntu20.04": {"dist": "ubuntu", "release": "focal", "label": "Ubuntu 20.04"},
    "ubuntu22.04": {"dist": "ubuntu", "release": "jammy", "label": "Ubuntu 22.04"},
    "ubuntu24.04": {"dist": "ubuntu", "release": "noble", "label": "Ubuntu 24.04"},
    "ubuntu26.04": {"dist": "ubuntu", "release": "resolute", "label": "Ubuntu 26.04"},
}

# Names that are safe to use as LXC container names.
SAFE_NAME = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_.-]{1,62}$")
VPS_ID_RE = re.compile(r"^[A-Za-z0-9_-]{4,64}$")

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

anti_events = defaultdict(deque)
panel_cache = {"name": CFG.get("DEFAULT_PANEL_NAME", "VPS Panel"),
               "url": CFG.get("DEFAULT_PANEL_URL", "")}
antinu_enabled = False


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS vps (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        owner_id INTEGER NOT NULL,
        owner_name TEXT NOT NULL,
        ram_gb INTEGER NOT NULL,
        disk_gb INTEGER NOT NULL,
        cpu INTEGER NOT NULL,
        os_key TEXT NOT NULL,
        os_label TEXT NOT NULL,
        container_name TEXT NOT NULL UNIQUE,
        backing_store TEXT NOT NULL DEFAULT 'dir',
        status TEXT NOT NULL DEFAULT 'STOPPED',
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admins (
        user_id INTEGER PRIMARY KEY
    );

    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS panels (
        name TEXT PRIMARY KEY,
        url TEXT NOT NULL
    );
    """)
    # Migrate databases created by V1.
    cols = {r[1] for r in con.execute("PRAGMA table_info(vps)").fetchall()}
    if "backing_store" not in cols:
        con.execute("ALTER TABLE vps ADD COLUMN backing_store TEXT NOT NULL DEFAULT 'dir'")
    con.commit()
    con.close()


def get_setting(key, default=None):
    con = db()
    row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    con.close()
    return row["value"] if row else default


def set_setting(key, value):
    con = db()
    con.execute("INSERT INTO settings(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(value)))
    con.commit()
    con.close()


def is_admin_id(user_id: int) -> bool:
    if user_id == bot.owner_id:
        return True
    con = db()
    row = con.execute("SELECT 1 FROM admins WHERE user_id=?", (user_id,)).fetchone()
    con.close()
    return bool(row)


async def is_admin(ctx):
    if is_admin_id(ctx.author.id):
        return True
    if isinstance(ctx.author, discord.Member):
        perms = ctx.author.guild_permissions
        if perms.administrator:
            return True
    return False


async def require_admin(ctx) -> bool:
    if await is_admin(ctx):
        return True
    await ctx.reply("❌ You do not have permission to use this admin command.", mention_author=False)
    return False


def now():
    return int(time.time())


def make_vps_id() -> str:
    import secrets
    return "vps-" + secrets.token_hex(4)


def run_cmd(cmd, timeout=COMMAND_TIMEOUT, check=False):
    return subprocess.run(
        cmd, text=True, capture_output=True, timeout=timeout, check=check
    )


async def run_cmd_async(cmd, timeout=COMMAND_TIMEOUT):
    def runner():
        return run_cmd(cmd, timeout=timeout)
    return await asyncio.to_thread(runner)


def lxc_exists(name):
    return (LXC_STORAGE / name).exists()


async def lxc_state(name) -> str:
    r = await run_cmd_async(["lxc-info", "-n", name, "-s"], 30)
    if r.returncode != 0:
        return "UNKNOWN"
    m = re.search(r"State:\s+(\S+)", r.stdout)
    return m.group(1).upper() if m else "UNKNOWN"


async def lxc_create(name: str, os_key: str, disk_gb: int):
    img = OS_IMAGES[os_key]
    backing = str(CFG.get("LXC_BACKING_STORE", "auto")).lower()
    if backing not in ("auto", "loop", "dir"):
        raise RuntimeError("LXC_BACKING_STORE must be auto, loop, or dir")

    # A loop backing store gives the guest a real filesystem of the requested
    # size. LXC documents -B loop together with --fssize for this purpose.
    use_loop = backing in ("auto", "loop")
    if use_loop:
        probe = await run_cmd_async(["bash", "-lc", "command -v losetup >/dev/null && losetup -f >/dev/null"], 20)
        if probe.returncode != 0:
            if backing == "loop":
                raise RuntimeError("Loop storage is required but losetup is unavailable on this host.")
            use_loop = False

    cmd = ["lxc-create", "-n", name]
    if use_loop:
        cmd += ["-B", "loop", "--fstype", "ext4", "--fssize", f"{disk_gb}G"]
    cmd += ["-t", CFG.get("LXC_TEMPLATE", "download"), "--",
            "--dist", img["dist"], "--release", img["release"],
            "--arch", CFG.get("LXC_ARCH", "amd64")]
    r = await run_cmd_async(cmd, max(COMMAND_TIMEOUT, 900))
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip() or r.stdout.strip() or "lxc-create failed")
    return "loop" if use_loop else "dir"


async def write_lxc_config(name, ram_gb, disk_gb, cpu):
    conf = LXC_STORAGE / name / "config"
    if not conf.exists():
        raise RuntimeError("LXC config was not created")

    # Never pin vCPU to host CPU IDs. cpu.max gives a real CPU quota and works
    # even when the host CPU numbering/topology is different.
    cpu_quota = int(cpu) * 100000
    limits = f"""
# VPSBOT-BEGIN
lxc.net.0.type = veth
lxc.net.0.link = {LXC_BRIDGE}
lxc.net.0.flags = up
lxc.net.0.name = eth0
lxc.cgroup2.memory.max = {int(ram_gb)}G
lxc.cgroup2.cpu.max = {cpu_quota} 100000
# VPSBOT-END
"""
    text = conf.read_text(encoding="utf-8")
    text = re.sub(r"\n# VPSBOT-BEGIN.*?# VPSBOT-END\n?", "\n", text, flags=re.S)
    conf.write_text(text.rstrip() + "\n" + limits.strip() + "\n", encoding="utf-8")


async def install_lxcfs_host():
    # LXCFS is a host-side service. Installing it inside a guest is not what
    # makes /proc/meminfo or /proc/cpuinfo container-aware.
    r = await run_cmd_async(["bash", "-lc", "command -v lxcfs >/dev/null 2>&1"], 20)
    if r.returncode != 0:
        return False
    running = await run_cmd_async(["bash", "-lc", "pgrep -x lxcfs >/dev/null 2>&1"], 20)
    if running.returncode == 0:
        return True
    # Do not require systemd; this also works in hosts where lxc-net.service
    # is unavailable.
    await run_cmd_async(["bash", "-lc", "mkdir -p /run/lxcfs; nohup lxcfs -f >/var/log/lxcfs-vpsbot.log 2>&1 &"], 20)
    await asyncio.sleep(2)
    check = await run_cmd_async(["bash", "-lc", "pgrep -x lxcfs >/dev/null 2>&1"], 20)
    return check.returncode == 0


async def install_guest_lxcfs(name):
    # Best-effort package installation inside the Ubuntu guest. The actual
    # container-aware proc/sys virtualization is provided by host LXCFS.
    await run_cmd_async(["lxc-attach", "-n", name, "--", "bash", "-lc",
        "export DEBIAN_FRONTEND=noninteractive; apt-get update -y && apt-get install -y lxcfs curl ca-certificates openssh-client || true"], 600)


async def set_guest_hostname(name, display_name):
    safe = re.sub(r"[^A-Za-z0-9_.-]", "-", display_name)[:50] or name
    await run_cmd_async(["lxc-attach", "-n", name, "--", "hostnamectl",
                         "set-hostname", safe], 60)


async def start_vps(name):
    log_file = f"/tmp/{name}-lxc-start.log"
    r = await run_cmd_async(["lxc-start", "-n", name, "-d", "-l", "ERROR", "-o", log_file], 90)
    if r.returncode != 0 and "already running" not in (r.stderr + r.stdout).lower():
        details = ""
        try:
            details = Path(log_file).read_text(errors="replace")[-5000:]
        except Exception:
            pass
        raise RuntimeError((r.stderr.strip() + "\n" + details).strip() or "lxc-start failed")


async def stop_vps(name):
    r = await run_cmd_async(["lxc-stop", "-n", name], 60)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip() or "lxc-stop failed")


async def restart_vps(name):
    r = await run_cmd_async(["lxc-restart", "-n", name], 90)
    if r.returncode != 0:
        await stop_vps(name)
        await asyncio.sleep(2)
        await start_vps(name)


async def delete_lxc(name):
    try:
        state = await lxc_state(name)
        if state == "RUNNING":
            await stop_vps(name)
    except Exception:
        pass
    r = await run_cmd_async(["lxc-destroy", "-n", name], 120)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip() or "lxc-destroy failed")


async def reinstall_vps(row):
    await delete_lxc(row["container_name"])
    await lxc_create(row["container_name"], row["os_key"], row["disk_gb"])
    await write_lxc_config(row["container_name"], row["ram_gb"], row["disk_gb"], row["cpu"])
    await start_vps(row["container_name"])
    await asyncio.sleep(3)
    await install_guest_lxcfs(row["container_name"])
    await set_guest_hostname(row["container_name"], row["name"])
    await stop_vps(row["container_name"])
    await start_vps(row["container_name"])


async def create_vps_record(name, ram_gb, disk_gb, cpu, os_key, owner: discord.Member):
    if os_key.lower() not in OS_IMAGES:
        aliases = {"20.04": "ubuntu20.04", "22.04": "ubuntu22.04",
                   "24.04": "ubuntu24.04", "26.04": "ubuntu26.04"}
        os_key = aliases.get(os_key.lower(), os_key.lower())
    if os_key not in OS_IMAGES:
        raise ValueError("OS must be one of: " + ", ".join(OS_IMAGES.keys()))
    if not SAFE_NAME.match(name):
        raise ValueError("Name must contain only letters, numbers, `_`, `-`, or `.` and be 2-63 characters.")
    if ram_gb < 1 or ram_gb > 512:
        raise ValueError("RAM must be between 1 and 512 GB.")
    if disk_gb < 1 or disk_gb > 16384:
        raise ValueError("Disk must be between 1 and 16384 GB.")
    if cpu < 1 or cpu > 128:
        raise ValueError("CPU must be between 1 and 128 vCPU.")
    if not owner:
        raise ValueError("Owner could not be resolved.")

    # Make container names globally unique and shell-safe.
    vps_id = make_vps_id()
    container_name = f"vps-{vps_id[4:]}"
    started = now()

    backing_store = await lxc_create(container_name, os_key, disk_gb)
    try:
        await write_lxc_config(container_name, ram_gb, disk_gb, cpu)
        await install_lxcfs_host()
        await start_vps(container_name)
        await asyncio.sleep(3)
        await install_guest_lxcfs(container_name)
        await set_guest_hostname(container_name, name)
        # Ensure final state is running.
    except Exception:
        try:
            await delete_lxc(container_name)
        except Exception:
            pass
        raise

    con = db()
    con.execute("""INSERT INTO vps
        (id,name,owner_id,owner_name,ram_gb,disk_gb,cpu,os_key,os_label,
         container_name,status,created_at,updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (vps_id, name, owner.id, str(owner), ram_gb, disk_gb, cpu,
         os_key, OS_IMAGES[os_key]["label"], container_name, backing_store, "RUNNING",
         started, started))
    con.commit()
    con.close()
    return vps_id


def get_vps(vps_id):
    con = db()
    row = con.execute("SELECT * FROM vps WHERE id=?", (vps_id,)).fetchone()
    con.close()
    return row


def get_user_vps(user_id):
    con = db()
    rows = con.execute("SELECT * FROM vps WHERE owner_id=? ORDER BY created_at DESC",
                       (user_id,)).fetchall()
    con.close()
    return rows


def all_vps():
    con = db()
    rows = con.execute("SELECT * FROM vps ORDER BY created_at DESC").fetchall()
    con.close()
    return rows


def delete_vps_db(vps_id):
    con = db()
    con.execute("DELETE FROM vps WHERE id=?", (vps_id,))
    con.commit()
    con.close()


async def generate_tmate(name):
    # SSH/tmate are deliberately separate from SSHX.
    # This produces the standard tmate SSH read/write connection URL.
    state = await lxc_state(name)
    if state != "RUNNING":
        await start_vps(name)
        await asyncio.sleep(3)
    cmd = ["lxc-attach", "-n", name, "--", "bash", "-lc",
           "command -v tmate >/dev/null 2>&1 || "
           "(apt-get update -y && DEBIAN_FRONTEND=noninteractive apt-get install -y tmate openssh-client); "
           "tmate -S /tmp/tmate.sock new-session -d; "
           "tmate -S /tmp/tmate.sock wait tmate-ready; "
           "tmate -S /tmp/tmate.sock display -p '#{tmate_ssh}'"]
    r = await run_cmd_async(cmd, 180)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip() or r.stdout.strip() or "tmate failed")
    link = r.stdout.strip().splitlines()[-1].strip()
    if not link.startswith("ssh "):
        # Some tmate versions can return an empty/format-different value.
        raise RuntimeError("tmate did not return an SSH connection string.")
    return link


async def generate_sshx(name):
    state = await lxc_state(name)
    if state != "RUNNING":
        await start_vps(name)
        await asyncio.sleep(3)
    # User specifically requested these commands for SSHX.
    cmd = ["lxc-attach", "-n", name, "--", "bash", "-lc",
           "command -v curl >/dev/null 2>&1 || "
           "(apt-get update -y && DEBIAN_FRONTEND=noninteractive apt-get install -y curl); "
           "curl -sSf https://sshx.io/get | sh && sshx"]
    r = await run_cmd_async(cmd, 180)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip() or r.stdout.strip() or "sshx failed")
    urls = re.findall(r"https://sshx\.io/s/[A-Za-z0-9_-]+#[A-Za-z0-9_-]+", r.stdout)
    if not urls:
        urls = re.findall(r"https://sshx\.io/s/\S+", r.stdout)
    if not urls:
        raise RuntimeError("sshx ran but no sshx.io link was found in its output.")
    return urls[-1].rstrip(").,`")


async def vps_stats(row):
    state = await lxc_state(row["container_name"])
    if state != "RUNNING":
        return {"state": state, "cpu": "0%", "memory": "0 / %s GB" % row["ram_gb"]}
    # Use LXC's cgroup statistics instead of the host's total allocation.
    mem = await run_cmd_async(["lxc-cgroup", "-n", row["container_name"],
                               "memory.current"], 30)
    cpu = await run_cmd_async(["lxc-cgroup", "-n", row["container_name"],
                               "cpu.stat"], 30)
    mem_bytes = 0
    try:
        mem_bytes = int(mem.stdout.strip())
    except Exception:
        pass
    mem_gb = mem_bytes / (1024**3)
    cpu_text = cpu.stdout.strip().replace("\n", " ")[:800] or "unavailable"
    return {"state": state, "cpu": cpu_text, "memory": f"{mem_gb:.2f} / {row['ram_gb']} GB"}


def vps_embed(row, title=None):
    e = discord.Embed(title=title or f"🖥️ {row['name']}", color=discord.Color.blurple())
    e.add_field(name="VPS ID", value=f"`{row['id']}`", inline=True)
    e.add_field(name="OS", value=row["os_label"], inline=True)
    e.add_field(name="Owner", value=f"<@{row['owner_id']}>", inline=True)
    e.add_field(name="RAM", value=f"{row['ram_gb']} GB", inline=True)
    e.add_field(name="Disk", value=f"{row['disk_gb']} GB", inline=True)
    e.add_field(name="CPU", value=f"{row['cpu']} vCPU", inline=True)
    e.add_field(name="Container", value=f"`{row['container_name']}`", inline=False)
    e.set_footer(text="LXC VPS Hosting")
    return e


class ManageView(discord.ui.View):
    def __init__(self, vps_id, owner_id, admin=False):
        super().__init__(timeout=900)
        self.vps_id = vps_id
        self.owner_id = owner_id
        self.admin = admin

    async def allowed(self, interaction):
        return interaction.user.id == self.owner_id or is_admin_id(interaction.user.id) or (
            isinstance(interaction.user, discord.Member) and interaction.user.guild_permissions.administrator
        )

    async def deny(self, interaction):
        await interaction.response.send_message("❌ You do not own this VPS.", ephemeral=True)

    @discord.ui.button(label="Reinstall", emoji="🔄", style=discord.ButtonStyle.secondary, row=0)
    async def reinstall(self, interaction, button):
        if not await self.allowed(interaction):
            return await self.deny(interaction)
        row = get_vps(self.vps_id)
        if not row:
            return await interaction.response.send_message("VPS not found.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            await reinstall_vps(row)
            con = db()
            con.execute("UPDATE vps SET status='RUNNING',updated_at=? WHERE id=?",
                        (now(), self.vps_id))
            con.commit(); con.close()
            await interaction.followup.send("✅ VPS reinstalled successfully.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Reinstall failed: `{str(e)[:1500]}`", ephemeral=True)

    @discord.ui.button(label="Start", emoji="▶️", style=discord.ButtonStyle.success, row=0)
    async def start(self, interaction, button):
        await self.lifecycle(interaction, "start")

    @discord.ui.button(label="Stop", emoji="⏸️", style=discord.ButtonStyle.danger, row=0)
    async def stop(self, interaction, button):
        await self.lifecycle(interaction, "stop")

    @discord.ui.button(label="Restart", emoji="🔄", style=discord.ButtonStyle.primary, row=1)
    async def restart(self, interaction, button):
        await self.lifecycle(interaction, "restart")

    @discord.ui.button(label="Delete VPS", emoji="🗑️", style=discord.ButtonStyle.danger, row=1)
    async def delete(self, interaction, button):
        if not await self.allowed(interaction):
            return await self.deny(interaction)
        row = get_vps(self.vps_id)
        if not row:
            return await interaction.response.send_message("VPS not found.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            await delete_lxc(row["container_name"])
            delete_vps_db(self.vps_id)
            await interaction.followup.send("🗑️ VPS deleted.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Delete failed: `{str(e)[:1500]}`", ephemeral=True)

    @discord.ui.button(label="SSH", emoji="🔑", style=discord.ButtonStyle.primary, row=2)
    async def ssh(self, interaction, button):
        if not await self.allowed(interaction):
            return await self.deny(interaction)
        row = get_vps(self.vps_id)
        if not row:
            return await interaction.response.send_message("VPS not found.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            key = await generate_tmate(row["container_name"])
            try:
                await interaction.user.send(
                    f"🔑 **SSH / tmate for `{row['name']}`**\n"
                    f"```text\n{key}\n```\n"
                    "Keep this connection string private."
                )
                await interaction.followup.send("✅ The tmate SSH connection string was sent to your DM.", ephemeral=True)
            except discord.Forbidden:
                await interaction.followup.send("❌ I generated it, but your DMs are closed. Enable DMs and try again.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ SSH generation failed: `{str(e)[:1500]}`", ephemeral=True)

    @discord.ui.button(label="SSHX", emoji="🌐", style=discord.ButtonStyle.primary, row=2)
    async def sshx(self, interaction, button):
        if not await self.allowed(interaction):
            return await self.deny(interaction)
        row = get_vps(self.vps_id)
        if not row:
            return await interaction.response.send_message("VPS not found.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            link = await generate_sshx(row["container_name"])
            try:
                await interaction.user.send(
                    f"🌐 **SSHX for `{row['name']}`**\n{link}"
                )
                await interaction.followup.send("✅ The SSHX link was sent to your DM.", ephemeral=True)
            except discord.Forbidden:
                await interaction.followup.send("❌ I generated it, but your DMs are closed.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ SSHX generation failed: `{str(e)[:1500]}`", ephemeral=True)

    @discord.ui.button(label="Stats", emoji="📊", style=discord.ButtonStyle.secondary, row=2)
    async def stats(self, interaction, button):
        if not await self.allowed(interaction):
            return await self.deny(interaction)
        row = get_vps(self.vps_id)
        if not row:
            return await interaction.response.send_message("VPS not found.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            s = await vps_stats(row)
            e = vps_embed(row, f"📊 Stats — {row['name']}")
            e.add_field(name="Status", value=s["state"], inline=True)
            e.add_field(name="Memory", value=s["memory"], inline=True)
            e.add_field(name="CPU cgroup", value=f"```text\n{s['cpu']}\n```", inline=False)
            await interaction.followup.send(embed=e, ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Stats failed: `{str(e)[:1500]}`", ephemeral=True)

    async def lifecycle(self, interaction, action):
        if not await self.allowed(interaction):
            return await self.deny(interaction)
        row = get_vps(self.vps_id)
        if not row:
            return await interaction.response.send_message("VPS not found.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            if action == "start":
                await start_vps(row["container_name"])
                status = "RUNNING"
            elif action == "stop":
                await stop_vps(row["container_name"])
                status = "STOPPED"
            else:
                await restart_vps(row["container_name"])
                status = "RUNNING"
            con = db()
            con.execute("UPDATE vps SET status=?,updated_at=? WHERE id=?",
                        (status, now(), self.vps_id))
            con.commit(); con.close()
            await interaction.followup.send(f"✅ VPS `{action}` completed.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ {action.title()} failed: `{str(e)[:1500]}`", ephemeral=True)


class ConfirmResetView(discord.ui.View):
    def __init__(self, author_id):
        super().__init__(timeout=60)
        self.author_id = author_id

    @discord.ui.button(label="CONFIRM RESET", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction, button):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message("Not your reset.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        errors = []
        for row in all_vps():
            try:
                await delete_lxc(row["container_name"])
            except Exception as e:
                errors.append(f"{row['id']}: {e}")
        con = db()
        con.execute("DELETE FROM vps")
        con.execute("DELETE FROM admins")
        con.execute("DELETE FROM panels")
        con.execute("DELETE FROM settings")
        con.commit(); con.close()
        await interaction.followup.send(
            "⚠️ **Bot reset complete.** All tracked VPS records and VPS containers were deleted."
            + (f"\nErrors: {len(errors)}" if errors else ""),
            ephemeral=True
        )


@bot.event
async def on_ready():
    init_db()
    global antinu_enabled
    antinu_enabled = get_setting("antinuke", "0") == "1"
    print(f"Logged in as {bot.user} ({bot.user.id})")
    print(f"Prefix: {PREFIX}")
    print("LXC VPS Discord Bot is ready.")


@bot.event
async def on_guild_channel_delete(channel):
    await anti_nuke_action(channel.guild, "channel_delete")


@bot.event
async def on_guild_role_delete(role):
    await anti_nuke_action(role.guild, "role_delete")


async def anti_nuke_action(guild, action):
    if not antinu_enabled:
        return
    # Audit log based protection. Discord requires View Audit Log.
    try:
        async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete
                                            if action == "channel_delete"
                                            else discord.AuditLogAction.role_delete):
            actor = entry.user
            if actor.id == bot.user.id or actor.id == guild.owner_id:
                return
            q = anti_events[(guild.id, actor.id)]
            nowt = time.time()
            window = int(CFG.get("ANTINUKE_WINDOW_SECONDS", 10))
            while q and nowt - q[0] > window:
                q.popleft()
            q.append(nowt)
            if len(q) >= int(CFG.get("ANTINUKE_MAX_ACTIONS", 3)):
                try:
                    await guild.ban(actor, reason="LXC VPS Bot Anti-Nuke: excessive destructive actions")
                except Exception:
                    pass
            return
    except Exception:
        return


@bot.command(name="myvps")
async def myvps(ctx):
    rows = get_user_vps(ctx.author.id)
    if not rows:
        return await ctx.reply("📭 You do not own any VPS.", mention_author=False)
    e = discord.Embed(title="🖥️ Your VPS", color=discord.Color.blurple())
    for row in rows[:25]:
        state = await lxc_state(row["container_name"])
        e.add_field(
            name=f"{row['name']} — `{row['id']}`",
            value=f"OS: {row['os_label']}\nRAM: {row['ram_gb']} GB • Disk: {row['disk_gb']} GB • CPU: {row['cpu']}\nStatus: **{state}**",
            inline=False
        )
    await ctx.reply(embed=e, mention_author=False)


@bot.command(name="ping")
async def ping(ctx):
    await ctx.reply(f"🏓 Pong! `{round(bot.latency * 1000)}ms`", mention_author=False)


@bot.command(name="new")
async def new_command(ctx, kind: Optional[str] = None, vps_id: Optional[str] = None):
    # Supports: Snew ssh <vps-id> and Snew sshx <vps-id>
    if kind is None or vps_id is None or kind.lower() not in ("ssh", "sshx"):
        return await ctx.reply("Usage: `Snew ssh <vps-id>` or `Snew sshx <vps-id>`", mention_author=False)
    row = get_vps(vps_id)
    if not row:
        return await ctx.reply("❌ VPS not found.", mention_author=False)
    if row["owner_id"] != ctx.author.id and not await is_admin(ctx):
        return await ctx.reply("❌ You do not own this VPS.", mention_author=False)
    async with ctx.typing():
        try:
            if kind.lower() == "ssh":
                value = await generate_tmate(row["container_name"])
                msg = f"🔑 **SSH / tmate — {row['name']}**\n```text\n{value}\n```"
            else:
                value = await generate_sshx(row["container_name"])
                msg = f"🌐 **SSHX — {row['name']}**\n{value}"
            await ctx.author.send(msg)
            await ctx.reply("✅ Sent to your DM.", mention_author=False)
        except Exception as e:
            await ctx.reply(f"❌ Failed: `{str(e)[:1500]}`", mention_author=False)


@bot.command(name="manage")
async def manage(ctx, vps_id: Optional[str] = None):
    if not vps_id:
        return await ctx.reply("Usage: `Smanage <vps-id>`", mention_author=False)
    row = get_vps(vps_id)
    if not row:
        return await ctx.reply("❌ VPS not found.", mention_author=False)
    if row["owner_id"] != ctx.author.id and not await is_admin(ctx):
        return await ctx.reply("❌ You do not own this VPS.", mention_author=False)
    state = await lxc_state(row["container_name"])
    e = vps_embed(row, f"⚙️ Manage — {row['name']}")
    e.add_field(name="Current Status", value=state, inline=False)
    await ctx.reply(embed=e, view=ManageView(vps_id, row["owner_id"], await is_admin(ctx)),
                    mention_author=False)


@bot.command(name="panel")
async def panel(ctx):
    if not panel_cache["url"]:
        return await ctx.reply("ℹ️ No panel has been added yet. Ask an admin to use `Saddpanel`.", mention_author=False)
    await ctx.reply(f"🌐 **{panel_cache['name']}**\n{panel_cache['url']}", mention_author=False)


@bot.command(name="help")
async def help_command(ctx):
    e = discord.Embed(title="📚 VPS Bot Help", color=discord.Color.blurple())
    e.add_field(name="User", value=(
        "`Smyvps` — list your VPS\n"
        "`Sping` — bot latency\n"
        "`Snew ssh <id>` — generate tmate SSH\n"
        "`Snew sshx <id>` — generate SSHX link\n"
        "`Smanage <id>` — manage your VPS\n"
        "`SPanel` — open the configured panel\n"
        "`Shelp` — this help"
    ), inline=False)
    if await is_admin(ctx):
        e.add_field(name="Admin", value=(
            "`Screatevps <name> <ram> <disk> <cpu> <os> <@user>`\n"
            "`Sdeletevps <id>`\n"
            "`Smanagevps [id]`\n"
            "`Saddpanel <name> <url>`\n"
            "`Saddadmin <@user>`\n"
            "`Screate embed <title> | <description>`\n"
            "`Senable antinuke` / `Sdisable antinuke`\n"
            "`Sban <@user>` / `Skick <@user>`\n"
            "`Sreset` — destructive reset"
        ), inline=False)
    await ctx.reply(embed=e, mention_author=False)


@bot.command(name="createvps")
async def createvps(ctx, name: Optional[str] = None, ram: Optional[str] = None,
                    disk: Optional[str] = None, cpu: Optional[str] = None,
                    os_key: Optional[str] = None, owner: Optional[discord.Member] = None):
    if not await require_admin(ctx):
        return
    if not all([name, ram, disk, cpu, os_key, owner]):
        return await ctx.reply(
            "Usage: `Screatevps <name> <ramGB> <diskGB> <cpu> <os> <@user>`\n"
            "Example: `Screatevps myvps 2 20 2 ubuntu22.04 @User`",
            mention_author=False)
    try:
        ram_i = int(ram)
        disk_i = int(re.sub(r"(?i)gb$", "", disk))
        cpu_i = int(re.sub(r"(?i)(vcpu|cpu)$", "", cpu))
        await ctx.reply("⏳ Creating the LXC VPS. This can take several minutes while the OS image and packages are installed.", mention_author=False)
        vps_id = await create_vps_record(name, ram_i, disk_i, cpu_i, os_key, owner)
        row = get_vps(vps_id)
        await ctx.send(f"✅ VPS created for {owner.mention}. VPS ID: `{vps_id}`", embed=vps_embed(row))
        try:
            await owner.send(
                f"🎉 **Your VPS is ready!**\n"
                f"Name: `{name}`\nVPS ID: `{vps_id}`\nOS: `{row['os_label']}`\n"
                f"RAM: `{ram_i} GB` • Disk: `{disk_i} GB` • CPU: `{cpu_i} vCPU`\n\n"
                "Use `Smanage <vps-id>` to manage it. SSH/tmate and SSHX are generated only when requested."
            )
        except discord.Forbidden:
            await ctx.send("⚠️ VPS created, but I could not DM the owner.")
    except Exception as e:
        await ctx.reply(f"❌ VPS creation failed: `{str(e)[:1800]}`", mention_author=False)


@bot.command(name="deletevps")
async def deletevps(ctx, vps_id: Optional[str] = None):
    if not await require_admin(ctx):
        return
    if not vps_id:
        return await ctx.reply("Usage: `Sdeletevps <vps-id>`", mention_author=False)
    row = get_vps(vps_id)
    if not row:
        return await ctx.reply("❌ VPS not found.", mention_author=False)
    try:
        await delete_lxc(row["container_name"])
        delete_vps_db(vps_id)
        await ctx.reply(f"🗑️ Deleted `{row['name']}` (`{vps_id}`).", mention_author=False)
    except Exception as e:
        await ctx.reply(f"❌ Delete failed: `{str(e)[:1500]}`", mention_author=False)


@bot.command(name="managevps")
async def managevps(ctx, vps_id: Optional[str] = None):
    if not await require_admin(ctx):
        return
    rows = [get_vps(vps_id)] if vps_id else all_vps()
    rows = [r for r in rows if r]
    if not rows:
        return await ctx.reply("📭 No VPS found.", mention_author=False)
    e = discord.Embed(title="🛠️ VPS Management", color=discord.Color.blurple())
    for row in rows[:25]:
        state = await lxc_state(row["container_name"])
        e.add_field(name=f"{row['name']} • `{row['id']}`",
                    value=f"Owner: <@{row['owner_id']}> • {row['os_label']}\n"
                          f"{row['ram_gb']}GB RAM • {row['disk_gb']}GB Disk • {row['cpu']} CPU\nStatus: **{state}**",
                    inline=False)
    await ctx.reply(embed=e, mention_author=False)


@bot.command(name="addpanel")
async def addpanel(ctx, name: Optional[str] = None, url: Optional[str] = None):
    if not await require_admin(ctx):
        return
    if not name or not url or not re.match(r"^https?://", url):
        return await ctx.reply("Usage: `Saddpanel <name> <https://panel.example>`", mention_author=False)
    panel_cache["name"], panel_cache["url"] = name, url
    con = db()
    con.execute("INSERT INTO panels(name,url) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET url=excluded.url",
                (name, url))
    con.commit(); con.close()
    await ctx.reply(f"✅ Panel `{name}` added.", mention_author=False)


@bot.command(name="addadmin")
async def addadmin(ctx, member: Optional[discord.Member] = None):
    if not await require_admin(ctx):
        return
    if not member:
        return await ctx.reply("Usage: `Saddadmin <@user>`", mention_author=False)
    con = db()
    con.execute("INSERT OR IGNORE INTO admins(user_id) VALUES(?)", (member.id,))
    con.commit(); con.close()
    await ctx.reply(f"✅ {member.mention} is now a VPS bot admin.", mention_author=False)


@bot.command(name="create")
async def create_command(ctx, sub: Optional[str] = None, *, content: str = ""):
    if not await require_admin(ctx):
        return
    if (sub or "").lower() != "embed":
        return await ctx.reply("Usage: `Screate embed <title> | <description>`", mention_author=False)
    if "|" not in content:
        return await ctx.reply("Usage: `Screate embed <title> | <description>`", mention_author=False)
    title, desc = [x.strip() for x in content.split("|", 1)]
    e = discord.Embed(title=title[:256], description=desc[:4096], color=discord.Color.blurple())
    await ctx.send(embed=e)


@bot.command(name="enable")
async def enable_command(ctx, sub: Optional[str] = None):
    global antinu_enabled
    if not await require_admin(ctx):
        return
    if (sub or "").lower() != "antinuke":
        return await ctx.reply("Usage: `Senable antinuke`", mention_author=False)
    antinu_enabled = True
    set_setting("antinuke", "1")
    await ctx.reply("🛡️ Anti-nuke enabled.", mention_author=False)


@bot.command(name="disable")
async def disable_command(ctx, sub: Optional[str] = None):
    global antinu_enabled
    if not await require_admin(ctx):
        return
    if (sub or "").lower() != "antinuke":
        return await ctx.reply("Usage: `Sdisable antinuke`", mention_author=False)
    antinu_enabled = False
    set_setting("antinuke", "0")
    await ctx.reply("🛡️ Anti-nuke disabled.", mention_author=False)


@bot.command(name="ban")
async def ban(ctx, member: Optional[discord.Member] = None, *, reason="Banned by VPS bot admin"):
    if not await require_admin(ctx):
        return
    if not member:
        return await ctx.reply("Usage: `Sban <@user> [reason]`", mention_author=False)
    try:
        await member.ban(reason=reason)
        await ctx.reply(f"🔨 Banned {member.mention}.", mention_author=False)
    except Exception as e:
        await ctx.reply(f"❌ Ban failed: `{e}`", mention_author=False)


@bot.command(name="kick")
async def kick(ctx, member: Optional[discord.Member] = None, *, reason="Kicked by VPS bot admin"):
    if not await require_admin(ctx):
        return
    if not member:
        return await ctx.reply("Usage: `Skick <@user> [reason]`", mention_author=False)
    try:
        await member.kick(reason=reason)
        await ctx.reply(f"👢 Kicked {member.mention}.", mention_author=False)
    except Exception as e:
        await ctx.reply(f"❌ Kick failed: `{e}`", mention_author=False)


@bot.command(name="reset")
async def reset(ctx, confirmation: Optional[str] = None):
    if not await require_admin(ctx):
        return
    if str(confirmation or "").upper() == "CONFIRM":
        errors = []
        for row in all_vps():
            try:
                await delete_lxc(row["container_name"])
            except Exception as exc:
                errors.append(f"{row['id']}: {exc}")
        con = db()
        con.execute("DELETE FROM vps"); con.execute("DELETE FROM admins"); con.execute("DELETE FROM panels"); con.execute("DELETE FROM settings")
        con.commit(); con.close()
        await ctx.reply("⚠️ Full reset completed." + (f" Errors: {len(errors)}" if errors else ""), mention_author=False)
        return
    e = discord.Embed(title="⚠️ RESET BOT", description="Deletes every tracked LXC VPS and bot data. Type `Sreset CONFIRM` to continue.", color=discord.Color.red())
    await ctx.reply(embed=e, mention_author=False)


if __name__ == "__main__":
    if not TOKEN or TOKEN.startswith("PUT_YOUR_"):
        print("ERROR: Set DISCORD_TOKEN in config.js before starting.")
        sys.exit(1)
    init_db()
    bot.run(TOKEN)
