module.exports = {
  DISCORD_TOKEN: "PUT_YOUR_DISCORD_BOT_TOKEN_HERE",
  GUILD_ID: 0,
  PREFIX: "S",
  LXC_STORAGE: "/var/lib/lxc",
  LXC_TEMPLATE: "download",
  LXC_ARCH: "amd64",
  LXC_BACKING_STORE: "auto",
  LXC_BRIDGE: "lxcbr0",
  DATABASE: "vpsbot.db",
  COMMAND_TIMEOUT: 300
};
