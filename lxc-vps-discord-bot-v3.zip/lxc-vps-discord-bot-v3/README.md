# LXC VPS Discord Bot V3

Built specifically around the Rigbox/Debian 12 problems found during testing.

## Fixed
- Removed `lxc-utils` (not available on Debian 12).
- No dependency on `lxc-net.service` or systemd.
- Creates `lxcbr0` directly.
- Configures dnsmasq DHCP and NAT.
- Starts LXCFS without systemd.
- Checks CAP_NET_ADMIN before continuing.
- Tests real `lxc-create` during install.
- Automatically installs/configures SSH in each guest.
- Automatically sets a root password.
- Waits for a guest IPv4 address.
- tmate and SSHX are generated only when requested.
- Real start/stop/restart/delete commands.
- RAM/CPU cgroup2 limits.
- FIXES the SQLite binding error by using exactly 12 placeholders for 12 inserted values.

## Install
```bash
chmod +x install.sh
sudo ./install.sh
```
Then edit `config.js`, set `DISCORD_TOKEN`, and run:
```bash
sudo ./run.sh
```

Test LXC independently:
```bash
sudo ./test-lxc.sh
```

## Create VPS
```text
Screatevps <name> <ramGB> <diskGB> <cpu> <os> <@user>
```
Example:
```text
Screatevps test1 2 10 2 ubuntu22 @User
```

## User
`Smyvps`
`Smanage <id>`
`Sping`
`Shelp`

## Admin
`Screatevps ...`
`Sdeletevps <id>`
`Smanagevps`
`Sreset CONFIRM`

Manage buttons: START, STOP, RESTART, SSH (tmate), SSHX, STATS.
