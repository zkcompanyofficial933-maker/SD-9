#!/usr/bin/env bash
set -Eeuo pipefail
GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'
step=0
log(){ echo -e "${GREEN}[STEP $step/14]${NC} $*"; }
die(){ echo -e "${RED}[ERROR]${NC} $*"; exit 1; }
(( EUID == 0 )) || die "Run: sudo ./install.sh"
export DEBIAN_FRONTEND=noninteractive
step=1; log "Updating package index"; apt-get update
step=2; log "Installing base utilities"; apt-get install -y ca-certificates curl wget gnupg2 lsb-release iproute2 iptables dnsmasq-base bridge-utils sudo openssh-client openssh-server python3 python3-venv python3-pip python3-dev build-essential uidmap fuse3
step=3; log "Installing LXC and LXCFS"; apt-get install -y lxc lxc-templates uidmap lxcfs
command -v lxc-create >/dev/null || die "lxc-create missing"
command -v lxc-start >/dev/null || die "lxc-start missing"
command -v lxc-info >/dev/null || die "lxc-info missing"
step=4; log "Checking LXC networking capability"; ip link add __vpsbot_test type dummy 2>/tmp/vpsbot-cap.err || { cat /tmp/vpsbot-cap.err; die "CAP_NET_ADMIN is unavailable; this host cannot run real LXC networking."; }; ip link del __vpsbot_test
step=5; log "Configuring LXC defaults"; mkdir -p /etc/lxc /etc/dnsmasq.d /var/lib/lxc; cat >/etc/lxc/default.conf <<'EOT'
lxc.net.0.type = veth
lxc.net.0.flags = up
lxc.net.0.link = lxcbr0
lxc.net.0.name = eth0
EOT
step=6; log "Creating lxcbr0"; ip link show lxcbr0 >/dev/null 2>&1 || ip link add lxcbr0 type bridge; ip addr replace 10.0.3.1/24 dev lxcbr0; ip link set lxcbr0 up
step=7; log "Configuring DHCP/DNS"; cat >/etc/dnsmasq.d/vpsbot-lxc.conf <<'EOT'
interface=lxcbr0
bind-interfaces
dhcp-range=10.0.3.10,10.0.3.250,255.255.255.0,12h
dhcp-option=3,10.0.3.1
dhcp-option=6,1.1.1.1,8.8.8.8
no-resolv
server=1.1.1.1
server=8.8.8.8
EOT
pkill -f 'dnsmasq.*vpsbot-lxc' 2>/dev/null || true
dnsmasq --conf-file=/etc/dnsmasq.d/vpsbot-lxc.conf --pid-file=/run/vpsbot-dnsmasq.pid
step=8; log "Enabling forwarding and NAT"; sysctl -w net.ipv4.ip_forward=1 >/dev/null; echo 'net.ipv4.ip_forward=1' >/etc/sysctl.d/99-vpsbot.conf; iptables -t nat -C POSTROUTING -s 10.0.3.0/24 ! -o lxcbr0 -j MASQUERADE 2>/dev/null || iptables -t nat -A POSTROUTING -s 10.0.3.0/24 ! -o lxcbr0 -j MASQUERADE; iptables -C FORWARD -i lxcbr0 -j ACCEPT 2>/dev/null || iptables -A FORWARD -i lxcbr0 -j ACCEPT; iptables -C FORWARD -o lxcbr0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || iptables -A FORWARD -o lxcbr0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
step=9; log "Starting LXCFS without systemd"; mkdir -p /run/lxcfs; pkill -x lxcfs 2>/dev/null || true; nohup lxcfs -f /run/lxcfs >/var/log/vpsbot-lxcfs.log 2>&1 & sleep 2; pgrep -x lxcfs >/dev/null || die "lxcfs failed; see /var/log/vpsbot-lxcfs.log"
step=10; log "Creating Python environment"; cd "$(dirname "$(readlink -f "$0")")"; python3 -m venv .venv; .venv/bin/python -m pip install --upgrade pip; .venv/bin/python -m pip install -r requirements.txt
step=11; log "Checking bot and database"; .venv/bin/python -m py_compile bot.py; .venv/bin/python - <<'PY'
import bot
bot.init_db()
print('Database initialization: OK')
PY
step=12; log "Testing real LXC create"; lxc-destroy -n vpsbot-install-test -f 2>/dev/null || true; lxc-create -n vpsbot-install-test -t download -- --dist ubuntu --release jammy --arch amd64; lxc-destroy -n vpsbot-install-test -f
step=13; log "Creating run helpers"; cat >run.sh <<'EOT'
#!/usr/bin/env bash
set -e
cd "$(dirname "$(readlink -f "$0")")"
exec .venv/bin/python bot.py
EOT
chmod +x run.sh
cat >test-lxc.sh <<'EOT'
#!/usr/bin/env bash
set -e
lxc-destroy -n vpsbot-test -f 2>/dev/null || true
lxc-create -n vpsbot-test -t download -- --dist ubuntu --release jammy --arch amd64
lxc-start -n vpsbot-test -d
sleep 5
lxc-info -n vpsbot-test
lxc-attach -n vpsbot-test -- ip -4 addr || true
lxc-stop -n vpsbot-test || true
lxc-destroy -n vpsbot-test -f || true
EOT
chmod +x test-lxc.sh
step=14; log "Installation completed"; echo; echo 'Edit config.js, set DISCORD_TOKEN, then run: sudo ./run.sh'; echo 'Independent test: sudo ./test-lxc.sh'; echo 'No lxc-net.service/systemd is required.'
