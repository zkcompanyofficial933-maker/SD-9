import asyncio, re, secrets, sqlite3, string, subprocess, time, shlex
from pathlib import Path
import discord
from discord.ext import commands

BASE=Path(__file__).resolve().parent
CONFIG=BASE/'config.js'
OS_MAP={'ubuntu20':('focal','Ubuntu 20.04'),'ubuntu22':('jammy','Ubuntu 22.04'),'ubuntu24':('noble','Ubuntu 24.04'),'ubuntu26':('resolute','Ubuntu 26.04')}

def cfg(name, default=None):
    s=CONFIG.read_text()
    m=re.search(rf'{re.escape(name)}\s*:\s*("(?:[^"\\]|\\.)*"|\d+)',s)
    if not m:return default
    v=m.group(1); return int(v) if v.isdigit() else v[1:-1]
TOKEN=cfg('DISCORD_TOKEN'); PREFIX=cfg('PREFIX','S'); DB=BASE/cfg('DATABASE','vpsbot.db'); BRIDGE=cfg('LXC_BRIDGE','lxcbr0'); TIMEOUT=cfg('COMMAND_TIMEOUT',600)

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    c=db(); c.execute('''CREATE TABLE IF NOT EXISTS vps (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,owner_id INTEGER NOT NULL,owner_name TEXT NOT NULL,ram_gb INTEGER NOT NULL,disk_gb INTEGER NOT NULL,cpu INTEGER NOT NULL,os_key TEXT NOT NULL,status TEXT NOT NULL,ip TEXT,root_password TEXT NOT NULL,created_at INTEGER NOT NULL,last_error TEXT)'''); c.commit(); c.close()

def run(cmd,timeout=120,check=True):
    p=subprocess.run(cmd,text=True,capture_output=True,timeout=timeout)
    if check and p.returncode!=0: raise RuntimeError((p.stderr or p.stdout or 'command failed').strip())
    return p.stdout.strip()

def exists(name): return subprocess.run(['lxc-info','-n',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0

def running(name):
    try:return 'RUNNING' in run(['lxc-info','-n',name])
    except:return False

def destroy(name):
    if running(name): run(['lxc-stop','-n',name],90,False)
    run(['lxc-destroy','-n',name,'-f'],120,False)

def create(name,oskey,ram,cpu):
    if exists(name): raise RuntimeError('A container with that name already exists.')
    rel,_=OS_MAP[oskey]
    run(['lxc-create','-n',name,'-t','download','--','--dist','ubuntu','--release',rel,'--arch','amd64'],TIMEOUT)
    p=Path('/var/lib/lxc')/name/'config'; old=p.read_text() if p.exists() else ''
    old=re.sub(r'(?m)^lxc.net.0\..*\n?','',old); old=re.sub(r'(?m)^lxc.cgroup2\..*\n?','',old)
    p.write_text(old.rstrip()+f'''\nlxc.net.0.type = veth\nlxc.net.0.flags = up\nlxc.net.0.link = {BRIDGE}\nlxc.net.0.name = eth0\nlxc.cgroup2.memory.max = {ram}G\nlxc.cgroup2.cpu.max = {cpu*100000} 100000\n''')

def start(name):
    log=f'/tmp/{name}-lxc-start.log'; run(['lxc-start','-n',name,'-d','-l','ERROR','-o',log],90)
    for _ in range(30):
        if running(name): return
        time.sleep(1)
    detail=Path(log).read_text(errors='replace') if Path(log).exists() else ''
    raise RuntimeError('Container failed to reach RUNNING.\n'+detail[-3500:])

def attach(name,cmd,timeout=180,check=True): return run(['lxc-attach','-n',name,'--','bash','-lc',cmd],timeout,check)

def guest_setup(name,pw):
    cmd="export DEBIAN_FRONTEND=noninteractive; for i in 1 2 3 4 5; do apt-get update && apt-get install -y openssh-server curl ca-certificates sudo passwd iproute2 && break; sleep 3; done; echo 'root:%s' | chpasswd; mkdir -p /run/sshd; sed -i 's/^#\\?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config; sed -i 's/^#\\?PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config; service ssh restart || service ssh start"%shlex.quote(pw)
    attach(name,cmd,300)
    for _ in range(30):
        try:
            out=attach(name,'ip -4 -o addr show dev eth0 2>/dev/null || true',20,False)
            m=re.search(r'inet\s+(\d+\.\d+\.\d+\.\d+)/',out)
            if m:return m.group(1)
        except:pass
        time.sleep(2)
    return None

def password(): return 'Vps@'+''.join(secrets.choice(string.ascii_letters+string.digits) for _ in range(14))

def save(d):
    # BUG FIX: the SQL has 13 placeholders and the tuple has exactly 13 values.
    sql='''INSERT INTO vps (name,owner_id,owner_name,ram_gb,disk_gb,cpu,os_key,status,ip,root_password,created_at,last_error) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)'''
    vals=(d['name'],d['owner_id'],d['owner_name'],d['ram_gb'],d['disk_gb'],d['cpu'],d['os_key'],d['status'],d['ip'],d['root_password'],d['created_at'],d['last_error'])
    assert len(vals)==12
    c=db(); c.execute(sql,vals); c.commit(); c.close()

def get(i):
    c=db(); r=c.execute('SELECT * FROM vps WHERE id=?',(i,)).fetchone(); c.close(); return r

def byname(n):
    c=db(); r=c.execute('SELECT * FROM vps WHERE name=?',(n,)).fetchone(); c.close(); return r

def mine(uid):
    c=db(); r=c.execute('SELECT * FROM vps WHERE owner_id=? ORDER BY id DESC',(uid,)).fetchall(); c.close(); return r

def upd(i,**kw):
    kw={k:v for k,v in kw.items() if k in {'status','ip','last_error','root_password'}}
    if not kw:return
    c=db(); c.execute('UPDATE vps SET '+','.join(k+'=?' for k in kw)+' WHERE id=?',(*kw.values(),i)); c.commit(); c.close()

class Manage(discord.ui.View):
    def __init__(self,i):super().__init__(timeout=900);self.i=i
    async def interaction_check(self,x):
        r=get(self.i); return bool(r and (r['owner_id']==x.user.id or x.user.guild_permissions.administrator))
    @discord.ui.button(label='START',emoji='▶️',style=discord.ButtonStyle.success)
    async def startb(self,x,b):
        await x.response.defer();r=get(self.i)
        try:start(r['name']);upd(self.i,status='running',last_error=None);await x.followup.send('✅ VPS started.')
        except Exception as e:await x.followup.send('❌ Start failed: `'+str(e)[:1700]+'`')
    @discord.ui.button(label='STOP',emoji='⏸️',style=discord.ButtonStyle.secondary)
    async def stopb(self,x,b):
        await x.response.defer();r=get(self.i)
        try:run(['lxc-stop','-n',r['name']],90);upd(self.i,status='stopped');await x.followup.send('⏸️ VPS stopped.')
        except Exception as e:await x.followup.send('❌ Stop failed: `'+str(e)[:1700]+'`')
    @discord.ui.button(label='RESTART',emoji='🔄',style=discord.ButtonStyle.primary)
    async def restartb(self,x,b):
        await x.response.defer();r=get(self.i)
        try:run(['lxc-stop','-n',r['name']],90,False);start(r['name']);upd(self.i,status='running',last_error=None);await x.followup.send('🔄 VPS restarted.')
        except Exception as e:await x.followup.send('❌ Restart failed: `'+str(e)[:1700]+'`')
    @discord.ui.button(label='SSH',emoji='🔑',style=discord.ButtonStyle.primary)
    async def sshb(self,x,b):
        await x.response.defer(ephemeral=True);r=get(self.i)
        try:
            if not running(r['name']):start(r['name'])
            attach(r['name'],"command -v tmate >/dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq tmate)",240)
            out=attach(r['name'],"tmate -S /tmp/vpsbot.sock new-session -d; tmate -S /tmp/vpsbot.sock wait tmate-ready; tmate -S /tmp/vpsbot.sock display -p '#{tmate_ssh}'",120)
            await x.user.send(f'🔑 VPS #{self.i} tmate SSH\n```{out.strip()}```');await x.followup.send('✅ tmate SSH sent to your DMs.',ephemeral=True)
        except Exception as e:await x.followup.send('❌ SSH failed: `'+str(e)[:1700]+'`',ephemeral=True)
    @discord.ui.button(label='SSHX',emoji='🌐',style=discord.ButtonStyle.primary)
    async def sshxb(self,x,b):
        await x.response.defer(ephemeral=True);r=get(self.i)
        try:
            if not running(r['name']):start(r['name'])
            attach(r['name'],"command -v sshx >/dev/null 2>&1 || curl -sSf https://sshx.io/get | sh",180)
            out=attach(r['name'],'timeout 30 sshx 2>&1 | tail -n 20',60)
            await x.user.send(f'🌐 VPS #{self.i} SSHX\n```{out.strip()}```');await x.followup.send('✅ SSHX sent to your DMs.',ephemeral=True)
        except Exception as e:await x.followup.send('❌ SSHX failed: `'+str(e)[:1700]+'`',ephemeral=True)
    @discord.ui.button(label='STATS',emoji='📊',style=discord.ButtonStyle.secondary)
    async def stat(self,x,b):
        await x.response.defer(ephemeral=True);r=get(self.i)
        try:await x.followup.send('```'+run(['lxc-info','-n',r['name']])[:1900]+'```',ephemeral=True)
        except Exception as e:await x.followup.send('❌ Stats failed: `'+str(e)[:1700]+'`',ephemeral=True)

intents=discord.Intents.default();intents.message_content=True
bot=commands.Bot(command_prefix=PREFIX,intents=intents)

@bot.event
async def on_ready(): print('Logged in as',bot.user)
@bot.command()
async def ping(ctx):await ctx.send(f'🏓 Pong `{round(bot.latency*1000)}ms`')
@bot.command(name='help')
async def helpcmd(ctx):await ctx.send(f'**User:** `{PREFIX}myvps` `{PREFIX}manage <id>` `{PREFIX}ping`\n**Admin:** `{PREFIX}createvps <name> <ram> <disk> <cpu> <os> <@user>` `{PREFIX}deletevps <id>` `{PREFIX}managevps` `{PREFIX}reset CONFIRM`\nOS: `ubuntu20` `ubuntu22` `ubuntu24` `ubuntu26`')
@bot.command()
async def myvps(ctx):
    rows=mine(ctx.author.id)
    if not rows:return await ctx.send('You have no VPS.')
    await ctx.send('\n'.join(f"**#{r['id']} {r['name']}** • {r['status']} • {r['ram_gb']}GB RAM • {r['cpu']} CPU • {r['disk_gb']}GB" for r in rows)[:1900])
@bot.command()
async def manage(ctx,i:int):
    r=get(i)
    if not r or (r['owner_id']!=ctx.author.id and not ctx.author.guild_permissions.administrator):return await ctx.send('❌ VPS not found or no access.')
    await ctx.send(f"**Manage VPS #{i} — {r['name']}**\nStatus: `{r['status']}`\nIP: `{r['ip'] or 'pending'}`",view=Manage(i))
@bot.command()
@commands.has_permissions(administrator=True)
async def createvps(ctx,name:str,ram:int,disk:int,cpu:int,oskey:str,user:str):
    oskey=oskey.lower()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{2,31}',name):return await ctx.send('❌ Invalid name.')
    if oskey not in OS_MAP:return await ctx.send('❌ OS: ubuntu20/22/24/26')
    if not(1<=ram<=128 and 1<=disk<=5000 and 1<=cpu<=64):return await ctx.send('❌ Invalid resources.')
    m=re.search(r'<@!?(\d+)>',user or '')
    if not m:return await ctx.send('❌ Mention the Discord user.')
    target=await bot.fetch_user(int(m.group(1)));msg=await ctx.send(f'⏳ Creating `{name}` for {target.mention}...');made=False
    try:
        pw=password();await asyncio.to_thread(create,name,oskey,ram,cpu);made=True;await asyncio.to_thread(start,name);ip=await asyncio.to_thread(guest_setup,name,pw)
        if not ip:raise RuntimeError('Container started but no IPv4 address was received. Check lxcbr0/dnsmasq/NAT.')
        d={'name':name,'owner_id':target.id,'owner_name':str(target),'ram_gb':ram,'disk_gb':disk,'cpu':cpu,'os_key':oskey,'status':'running','ip':ip,'root_password':pw,'created_at':int(time.time()),'last_error':None}
        await asyncio.to_thread(save,d);r=byname(name);e=discord.Embed(title='✅ VPS Created',color=0x57F287);e.add_field(name='VPS ID',value=str(r['id']));e.add_field(name='IP',value=ip);e.add_field(name='Login',value='`root`');e.add_field(name='Password',value=f'||{pw}||');e.add_field(name='Resources',value=f'{ram} GB RAM • {cpu} CPU • {disk} GB disk');await msg.edit(content=None,embed=e,view=Manage(r['id']));
        try:await target.send(embed=e)
        except:pass
    except Exception as e:
        if made:destroy(name)
        await msg.edit(content=f'❌ VPS creation failed: `{str(e)[:1800]}`')
@bot.command()
@commands.has_permissions(administrator=True)
async def deletevps(ctx,i:int):
    r=get(i)
    if not r:return await ctx.send('❌ VPS not found.')
    try:await asyncio.to_thread(destroy,r['name']);c=db();c.execute('DELETE FROM vps WHERE id=?',(i,));c.commit();c.close();await ctx.send(f'🗑️ VPS #{i} deleted.')
    except Exception as e:await ctx.send('❌ Delete failed: `'+str(e)[:1700]+'`')
@bot.command()
@commands.has_permissions(administrator=True)
async def managevps(ctx):
    c=db();rows=c.execute('SELECT * FROM vps ORDER BY id DESC').fetchall();c.close();await ctx.send(('\n'.join(f"#{r['id']} `{r['name']}` → <@{r['owner_id']}> → {r['status']}" for r in rows) or 'No VPS.')[:1900])
@bot.command()
@commands.has_permissions(administrator=True)
async def reset(ctx,confirm=''):
    if confirm.upper()!='CONFIRM':return await ctx.send(f'⚠️ Run `{PREFIX}reset CONFIRM` to delete all tracked VPS.')
    c=db();rows=c.execute('SELECT name FROM vps').fetchall();c.close()
    for r in rows:await asyncio.to_thread(destroy,r['name'])
    c=db();c.execute('DELETE FROM vps');c.commit();c.close();await ctx.send('♻️ All VPS deleted.')
@bot.event
async def on_command_error(ctx,e):
    if isinstance(e,commands.MissingPermissions):return await ctx.send('❌ Administrator permission required.')
    if isinstance(e,commands.MissingRequiredArgument):return await ctx.send(f'❌ Missing argument. Use `{PREFIX}help`.')
    if isinstance(e,commands.BadArgument):return await ctx.send(f'❌ Invalid argument. Use `{PREFIX}help`.')
    if not isinstance(e,commands.CommandNotFound):print('Command error:',e)

if __name__=='__main__':
    init_db()
    if not TOKEN or TOKEN.startswith('PUT_YOUR'):raise SystemExit('Set DISCORD_TOKEN in config.js first.')
    bot.run(TOKEN)
