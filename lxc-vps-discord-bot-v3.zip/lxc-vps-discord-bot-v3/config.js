module.exports = {
  DISCORD_TOKEN: "PUT_YOUR_DISCORD_BOT_TOKEN_HERE",
  PREFIX: "S",
  LXC_STORAGE: "/var/lib/lxc",
  LXC_BRIDGE: "lxcbr0",
  LXC_SUBNET: "10.0.3.0/24",
  LXC_GATEWAY: "10.0.3.1",
  DATABASE: "vpsbot.db",
  COMMAND_TIMEOUT: 600
};
